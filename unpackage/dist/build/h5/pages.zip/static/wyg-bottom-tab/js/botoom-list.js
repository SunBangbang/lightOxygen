const LIST = [{
		id: 1,
		name: "首页",
		imgOff: "../../static/wyg-bottom-tab/img/icon_01.png",
		imgOn: "../../static/wyg-bottom-tab/img/icon_01_f.png",
		"url": "/pages/index/index"
	},
	{
		id: 2,
		name: "分类",
		imgOff: "../../static/wyg-bottom-tab/img/icon_02.png",
		imgOn: "../../static/wyg-bottom-tab/img/icon_02_f.png",
		"url": "/pages/index/cate"
	},
	{
		id: 3,
		name: "购物车",
		imgOff: "../../static/wyg-bottom-tab/img/icon_03.png",
		imgOn: "../../static/wyg-bottom-tab/img/icon_03_f.png",
		"url": "/pages/index/cart"
	},
	{
		id: 4,
		name: "个人中心",
		imgOff: "../../static/wyg-bottom-tab/img/icon_04.png",
		imgOn: "../../static/wyg-bottom-tab/img/icon_04_f.png",
		"url": "/pages/index/user"
	}
]

export default LIST;
